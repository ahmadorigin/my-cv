<?php include 'header.php'; ?>
      <h1>Gallery</h1>
      
      <div class="container">
            <table>
                  <tr>
                        <td><img src="./assets/image1.jpg" alt="Image 1" width="200"></td>
                        <td><img src="./assets/image2.jpg" alt="Image 2" width="200"></td>
                        <td><img src="./assets/image3.jpg" alt="Image 3" width="200"></td>
                  </tr>
                  <tr>
                        <td><img src="./assets/image4.jpg" alt="Image 4" width="200"></td>
                        <td><img src="./assets/image5.jpg" alt="Image 5" width="200"></td>
                        <td><img src="./assets/image6.jpg" alt="Image 6" width="200"></td>
                  </tr>
                  <tr>
                        <td><img src="./assets/image7.jpg" alt="Image 7" width="200"></td>
                        <td><img src="./assets/image8.jpg" alt="Image 8" width="200"></td>
                        <td><img src="./assets/image9.jpg" alt="Image 9" width="200"></td>
                  </tr>
            </table>
      </div>
<?php include 'footer.php'; ?>