<?php include 'header.php'; ?>
      <h1>Contact</h1>
<?php include 'footer.php'; ?>