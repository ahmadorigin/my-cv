
    <footer>
      <p style="text-align: center; margin-top: 40px">
        &copy; 2024 My Website. All rights reserved.
      </p>
    </footer>
  </body>
</html>