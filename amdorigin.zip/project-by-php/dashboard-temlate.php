<?php include 'header.php'; ?>
    <div class="h1">
      <h1>Welcome to my website</h1>
      <p>Hello World</p>
    </div>
    <div class="box">
      <div class="item-box item1">
        <div class="header-item-box">
          <h3>Paket A</h3>
          <span>Lite</span>
        </div>
        <div class="body-item-box">
          <h2>Rp 5.000</h2>
          <span>/M2</span>
          <ul>
            <li>Nasi uduk++</li>
            <li>Es teh panas</li>
            <li>Krupuk</li>
            <li>3 jenis gorengan</li>
            <li>Weifie gratiss</li>
          </ul>
        </div>
      </div>
      <div class="item-box item2">
        <div class="header-item-box">
          <h3>Paket B</h3>
          <span>Beginner</span>
        </div>
        <div class="body-item-box">
          <h2>Rp 10.000</h2>
          <span>/M2</span>
          <ul>
            <li>Nasi uduk++</li>
            <li>Es teh panas</li>
            <li>Krupuk</li>
            <li>3 jenis gorengan</li>
            <li>Weifie gratiss</li>
          </ul>
        </div>
      </div>
      <div class="item-box item3">
        <div class="header-item-box">
          <h3>Paket C</h3>
          <span>Medium</span>
        </div>
        <div class="body-item-box">
          <h2>Rp 15.000</h2>
          <span>/M2</span>
          <ul>
            <li>Nasi uduk++</li>
            <li>Es teh panas</li>
            <li>Krupuk</li>
            <li>3 jenis gorengan</li>
            <li>Weifie gratiss</li>
          </ul>
        </div>
      </div>
      <div class="item-box item4">
        <div class="header-item-box">
          <h3>Paket D</h3>
          <span>Advanced</span>
        </div>
        <div class="body-item-box">
          <h2>Rp 20.000</h2>
          <span>/M2</span>
          <ul>
            <li>Nasi uduk++</li>
            <li>Es teh panas</li>
            <li>Krupuk</li>
            <li>3 jenis gorengan</li>
            <li>Weifie gratiss</li>
          </ul>
        </div>
      </div>
    </div>
    <br />
    <div class="box2">
      <div class="item-box item1">
        <div class="header-item-box">
          <h3>Paket A</h3>
          <span>Lite</span>
        </div>
        <div class="body-item-box">
          <h2>Rp 5.000</h2>
          <span>/M2</span>
          <ul>
            <li>Nasi uduk++</li>
            <li>Es teh panas</li>
            <li>Krupuk</li>
            <li>3 jenis gorengan</li>
            <li>Weifie gratiss</li>
          </ul>
        </div>
      </div>
      <div class="item-box item2">
        <div class="header-item-box">
          <h3>Paket B</h3>
          <span>Beginner</span>
        </div>
        <div class="body-item-box">
          <h2>Rp 10.000</h2>
          <span>/M2</span>
          <ul>
            <li>Nasi uduk++</li>
            <li>Es teh panas</li>
            <li>Krupuk</li>
            <li>3 jenis gorengan</li>
            <li>Weifie gratiss</li>
          </ul>
        </div>
      </div>
      <div class="item-box item3">
        <div class="header-item-box">
          <h3>Paket C</h3>
          <span>Medium</span>
        </div>
        <div class="body-item-box">
          <h2>Rp 15.000</h2>
          <span>/M2</span>
          <ul>
            <li>Nasi uduk++</li>
            <li>Es teh panas</li>
            <li>Krupuk</li>
            <li>3 jenis gorengan</li>
            <li>Weifie gratiss</li>
          </ul>
        </div>
      </div>
      <div class="item-box item4">
        <div class="header-item-box">
          <h3>Paket D</h3>
          <span>Advanced</span>
        </div>
        <div class="body-item-box">
          <h2>Rp 20.000</h2>
          <span>/M2</span>
          <ul>
            <li>Nasi uduk++</li>
            <li>Es teh panas</li>
            <li>Krupuk</li>
            <li>3 jenis gorengan</li>
            <li>Weifie gratiss</li>
          </ul>
        </div>
      </div>
    </div>
<?php include 'footer.php'; ?>