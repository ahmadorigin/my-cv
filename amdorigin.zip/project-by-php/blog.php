<?php include 'header.php'; ?>
      <h1>Blog</h1>      
<?php include 'footer.php'; ?>