<?php include 'header.php'; ?>
      <h1>About</h1>
      <img src="./assets/blog-img.jpg" alt="Blog Image" class="img-profile"/>

      <table class="about-table">
            <tr>
                  <th>Nama :</th>
                  <td>Muh. Abdullah</td>
            </tr>
            <tr>
                  <th>NIM :</th>
                  <td>0284092809802</td>
            </tr>
            <tr>
                  <th>Kelas :</th>
                  <td>X</td>
            </tr>
            <tr>
                  <th>Tgl lahir :</th>
                  <td>13 | 7 | 09</td>
            </tr>
            <tr>
                  <th>Telepon :</th>
                  <td>019983027</td>
            </tr>
      </table>
<?php include 'footer.php'; ?>